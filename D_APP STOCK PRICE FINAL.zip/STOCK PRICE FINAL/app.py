import pandas as pd
import streamlit as st
import pickle
from sklearn.preprocessing import StandardScaler



fp= open("model.pkl","rb")
clf= pickle.load(fp)
sc=pickle.load(open("scaler.pkl","rb"))

def main():
    page_bg_img = f"""
    <style>
    [data-testid="stAppViewContainer"] > .main {{
    background-image: url("https://img.freepik.com/premium-vector/stock-market-wizard-expertise-trader-make-profit-from-crypto-bitcoin-using-magic-get-rich-like-miracle-concept-businessman-investment-wizard-using-magic-wand-make-stock-price-rising-up_212586-1191.jpg?w=2000");
    background-size: 90%
    }}
    </style>
    """
    st.markdown(page_bg_img, unsafe_allow_html=True)
   
    st.title(":black[ADANI STOCK MARKET OPENING PRICE PREDICTION]")
    left,right=st.columns((2,2))
    Close= left.number_input(":red[**Enter Closing Price:**]",min_value=0.00)
    High= right.number_input(":red[**Enter Highest Price:**]",min_value=0.00)
    Low= left.number_input(":red[**Enter Lowest Price:**]",min_value=0.00)
    Volume= right.number_input(":red[**Enter Volume of Stock:**]",step=1,value=0)
    predict_button= st.button(":green[**Predict Opening Price**]") # to get button

    data=sc.transform([[Close,High,Low,Volume]])

    if predict_button:
        res=clf.predict(data)
        left,right=st.columns((2,2))
        left.write("**The estimated Stock opening price (in Rs.) is:**")
        right.write(res)
if __name__ == "__main__":
    main()